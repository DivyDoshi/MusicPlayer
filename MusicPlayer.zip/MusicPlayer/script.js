// Step-1: Songs Data
const songs = [
  {
    id: 1,
    name: "You And Me",
    artist: "Shubh",
    genre: "Hip-Hop",
    img: "./assets/download.jpeg",
    source: "songs/You_And_Me_1.mp3",
  },
  {
    id: 2,
    name: "100 Million",
    artist: "Karan Aujla",
    genre: "Hip-Hop",
    img: "./assets/320100 Million - Karan Aujla 320 Kbps.jpg",
    source: "songs/128-100 Million - Karan Aujla 128 Kbps.mp3",
  },
  {
    id: 3,
    name: "Tauba Tauba",
    artist: "Karan Aujla",
    genre: "Rock",
    img: "./assets/320Tauba Tauba - Bad Newz 320 Kbps.jpg",
    source: "songs/Tauba Tauba - Bad Newz 128 Kbps.mp3",
  },
  {
    id: 4,
    name: "Mera Na",
    artist: "Sidhu MooseWala",
    genre: "Hip-Hop",
    img: "./assets/320Mera Na - Sidhu Moose Wala 320 Kbps.jpg",
    source: "songs/Mera Na - Sidhu Moose Wala 128 Kbps.mp3",
  },
  {
    id: 5,
    name: "Lashkare",
    artist: "YoYo HoneySingh",
    genre: "Pop",
    img: "./assets/320Lashkare - Yo Yo Honey Singh 320 Kbps.jpg",
    source: "songs/Lashkare - Yo Yo Honey Singh 128 Kbps.mp3",
  },
  {
    id: 6,
    name: "Singham Again",
    artist: "Singham",
    genre: "Rock",
    img: "./assets/128Singham Again Title Track - Singham Again 128 Kbps.jpg",
    source: "songs/Singham Again Title Track - Singham Again 128 Kbps.mp3",
  },
  {
    id: 7,
    name: "Rooh",
    artist: "YoYo HoneySingh",
    genre: "Pop",
    img: "./assets/128Rooh - Yo Yo Honey Singh 128 Kbps.jpg",
    source: "songs/Rooh - Yo Yo Honey Singh 128 Kbps.mp3",
  },
  {
    id: 8,
    name: "Pushpa Pushpa",
    artist: "Mika Singh",
    genre: "Rock",
    img: "./assets/128Pushpa Pushpa - Pushpa 2 The Rule 128 Kbps.jpg",
    source: "songs/Pushpa Pushpa - Pushpa 2 The Rule 128 Kbps.mp3",
  },
  {
    id: 9,
    name: "Kissik",
    artist: "Shri DeviPrasad",
    genre: "Rock",
    img: "./assets/128Kissik - Pushpa 2 The Rule 128 Kbps.jpg",
    source: "songs/Kissik - Pushpa 2 The Rule 128 Kbps.mp3",
  },
  {
    id: 10,
    name: "Hauli Hauli",
    artist: "Guru Randhawa",
    genre: "Hip-Hop",
    img: "./assets/128Hauli Hauli - Khel Khel Mein 128 Kbps.jpg",
    source: "songs/Hauli Hauli - Khel Khel Mein 128 Kbps.mp3",
  },
  {
    id: 11,
    name: "Agar Ho Tum",
    artist: "Arjit Singh",
    genre: "Pop",
    img: "./assets/128Agar Ho Tum - Mr. And Mrs. Mahi 128 Kbps.jpg",
    source: "songs/Agar Ho Tum - Mr. And Mrs. Mahi 128 Kbps.mp3",
  },
  {
    id: 12,
    name: "Aayi Nai",
    artist: "Sachin-Jigar",
    genre: "Pop",
    img: "./assets/128Aayi Nai - Stree 2 128 Kbps.jpg",
    source: "songs/Aayi Nai - Stree 2 128 Kbps.mp3",
  },
  {
    id: 13,
    name: "Bhool Bhulaiyaa",
    artist: "Diljit Dosanjh",
    genre: "Pop",
    img: "./assets/128Bhool Bhulaiyaa 3 - Title Track (Feat. Pitbull) - Bhool Bhulaiyaa 3 128 Kbps.jpg",
    source: "songs/Bhool Bhulaiyaa 3 - Title Track (Feat. Pitbull) - Bhool Bhulaiyaa 3 128 Kbps.mp3",
  },
];

// Step-2: Show Songs
function showSongs(selectedGenre = "All") {
  const songListContainer = document.getElementById("songs-container");
  songListContainer.innerHTML = ""; // Clear current list

  const filteredSongs = selectedGenre === "All" 
    ? songs 
    : songs.filter((song) => song.genre === selectedGenre);

  filteredSongs.forEach((song) => {
    const songElement = document.createElement("button");
    songElement.textContent = `${song.name} - ${song.artist}`;
    songElement.classList.add("song-button"); // Add a class for styling
    songElement.onclick = () => renderCurrentSong(song);
    songListContainer.appendChild(songElement);
  });
}

window.onload = () => showSongs();

// Step-3: Render Current Song
let currentSongIndex = 0;

function renderCurrentSong(song) {
  currentSongIndex = songs.findIndex((s) => s.id === song.id);
  const audioPlayer = document.getElementById("audio");
  const songImage = document.getElementById("song-img");
  const songTitle = document.getElementById("song-title");
  const songArtist = document.getElementById("song-artist");

  audioPlayer.src = song.source;
  songImage.src = song.img;
  songTitle.textContent = song.name;
  songArtist.textContent = song.artist;

  audioPlayer.play();
}

// Step-4: Play Next & Previous
function playNext() {
  currentSongIndex = (currentSongIndex + 1) % songs.length;
  renderCurrentSong(songs[currentSongIndex]);
}

function playPrevious() {
  currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
  renderCurrentSong(songs[currentSongIndex]);
}

// Step-5: Playlist Management
const playlists = {};
let selectedPlaylist = null;

function createPlaylist() {
  const playlistNameInput = document.getElementById("playlist-input");
  const playlistName = playlistNameInput.value.trim();

  if (playlistName === "") {
    alert("Playlist name cannot be empty!");
    return;
  }

  if (playlists[playlistName]) {
    alert("Playlist already exists!");
    return;
  }

  playlists[playlistName] = [];
  playlistNameInput.value = ""; // Clear the input field
  renderPlaylists();
}

function renderPlaylists() {
  const allPlaylistsContainer = document.getElementById("playlists");
  allPlaylistsContainer.innerHTML = ""; // Clear previous content

  for (const playlist in playlists) {
    const playlistDiv = document.createElement("div");
    playlistDiv.textContent = playlist;
    playlistDiv.onclick = () => selectPlaylist(playlist);
    allPlaylistsContainer.appendChild(playlistDiv);
  }
}

function selectPlaylist(playlistName) {
  selectedPlaylist = playlistName;
  alert(`Selected playlist: ${playlistName}`);
  renderCurrentPlaylist();
}

function addToPlaylist() {
  if (!selectedPlaylist) {
    alert("Please select a playlist first!");
    return;
  }

  const song = songs[currentSongIndex];

  if (!playlists[selectedPlaylist]) playlists[selectedPlaylist] = [];

  playlists[selectedPlaylist].push(song);
  renderCurrentPlaylist();
}

function removeFromPlaylist(songId) {
  if (!selectedPlaylist) {
    alert("Please select a playlist first!");
    return;
  }

  const playlist = playlists[selectedPlaylist];
  const updatedPlaylist = playlist.filter((song) => song.id !== songId);

  playlists[selectedPlaylist] = updatedPlaylist; // Update the playlist
  renderCurrentPlaylist();
}

function renderCurrentPlaylist() {
  const currentPlaylistElement = document.getElementById("current-songs");
  currentPlaylistElement.innerHTML = ""; // Clear the previous playlist content

  if (!selectedPlaylist) {
    currentPlaylistElement.innerHTML = "<em>No playlist selected</em>";
    return;
  }

  const playlistSongs = playlists[selectedPlaylist];
  if (playlistSongs.length === 0) {
    currentPlaylistElement.innerHTML = "<em>Playlist is empty</em>";
    return;
  }

playlistSongs.forEach((song) => {
    const songContainer = document.createElement("div");
    songContainer.className = "playlist-song-container";

    const songButton = document.createElement("button");
    songButton.textContent = `${song.name} - ${song.artist}`;
    songButton.classList.add("song-button"); // Add a class for styling the song button
    songButton.onclick = () => renderCurrentSong(song);

    const removeButton = document.createElement("button");
    removeButton.textContent = "✖"; // Cross icon
    removeButton.classList.add("remove-button"); // Add a class for styling the remove button
    removeButton.onclick = () => removeFromPlaylist(song.id);

    songContainer.appendChild(songButton);
    songContainer.appendChild(removeButton);
    currentPlaylistElement.appendChild(songContainer);
  });
}

// Step-6: Theme Toggle
function toggleTheme() {
  const body = document.body;
  const themeText = document.getElementById("toggle-text");
  const currentTheme = body.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";
  body.setAttribute("data-theme", newTheme);

  themeText.textContent = newTheme === "dark" ? "Dark" : "Light";
}

// Step-7: Search Functionality
const songSearch = document.getElementById("song-search");
songSearch.addEventListener("input", filterSongs);

function filterSongs() {
  const query = songSearch.value.toLowerCase();
  const filteredSongs = songs.filter(
    (song) =>
      song.name.toLowerCase().includes(query) ||
      song.artist.toLowerCase().includes(query)
  );
  const songListContainer = document.getElementById("songs-container");
  songListContainer.innerHTML = ""; // Clear current list

  filteredSongs.forEach((song) => {
    const songElement = document.createElement("button");
    songElement.textContent = `${song.name} - ${song.artist}`;
    songElement.classList.add("song-button"); // Add a class for styling
    songElement.onclick = () => renderCurrentSong(song);
    songListContainer.appendChild(songElement);
  });
}

const playlistSearch = document.getElementById("playlist-search");
playlistSearch.addEventListener("input", filterPlaylists);

function filterPlaylists() {
  const query = playlistSearch.value.toLowerCase();
  const allPlaylistsContainer = document.getElementById("playlists");
  allPlaylistsContainer.innerHTML = ""; // Clear previous playlists

  for (const playlist in playlists) {
    if (playlist.toLowerCase().includes(query)) {
      const playlistDiv = document.createElement("div");
      playlistDiv.textContent = playlist;
      playlistDiv.onclick = () => selectPlaylist(playlist);
      allPlaylistsContainer.appendChild(playlistDiv);
    }
  }
}
